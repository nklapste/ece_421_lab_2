class Apple
  def self.sayName
    puts "Hello! I am an apple"
  end
  
  def self.sayColor
    puts "I am red in color!"
  end  
end
