module Fruits
    def self.saySomething()
        puts "Fruits are good for health"
    end
    module Red
        COLOR = "Red"
        class Apple
            def sayName()
                puts "Hello from Apple and I am #{COLOR} in color"
            end
        end
        class Cherry
            def sayName()
                puts "Hello from Cherry and I am #{COLOR} in color"
            end
        end
        class Strawberry
            def sayName()
                # Accessing the value of COLOR from module Green
                puts "Hello from Strawberry and I am not #{Green::COLOR} in color"
            end
        end
        def self.foo()
            puts "Inside module #{COLOR}"
        end
    end
    module Green
        COLOR = "Green"
        class Avocados
            def sayName()
                puts "Hello from Avocados and I am #{COLOR} in color"
            end
        end
        class Limes
            def sayName()
                puts "Hello from Limes and I am not #{Red::COLOR} in color"
            end
        end
        
        def self.bar()
            puts "Inside module #{COLOR}"
        end
    end
end
