module TestEven				## Defining module TestEven
    def iseven?
        @number % 2 == 0
    end
    def isodd?
        !self.iseven?
    end
end

class Number				## Defining class Number
    include TestEven			
    def initialize(arg = 0)
        @number = arg
    end
    def display
        print @number
    end    
end

puts "A sample program for testing Mixins in Ruby"
obj = Number.new(39)
print "The number is ";obj.display
puts
					## Testing the 'Mixin' code			
if obj.iseven?
    puts "#{obj.display} is an Even number"
else
    puts "#{obj.display} is an Odd number"
end


## Task: Comment the 'include TestEven' statement in class Number and try to execute the code, it should throw an error



